# Overview - Ethiopia HIV IG (sandbox demo subset) v0.1.0

* [**Table of Contents**](toc.md)
* **Overview**

## Overview

| | |
| :--- | :--- |
| *Official URL*:http://fhir.et/hiv/ImplementationGuide/et.fhir.hiv | *Version*:0.1.0 |
| Draft as of 2026-06-17 | *Computable Name*:ETHIV |

### Ethiopia HIV IG (sandbox demo subset)

Minimal HIV IG for the conformance sandbox. Depends on [`et.fhir.surveillance`](http://fhir.et/surveillance) (and transitively [`et.fhir.core`](http://fhir.et/core)). Enables `HIVPatient` (requires an ART number), `HIVEncounter`, and `HIVMedicationDispense` for the medication-dispense scenario; the rest of the HIV content ships disabled.

